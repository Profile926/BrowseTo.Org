"TV Viewer"
Website: http://tvviewer.browseto.org

This program is shareware. After a trial period of 30 days, you are required
to register this program. For more info see the registration section
in this document.
--------------------------------------------------------------------------

Copyright (c) 2000-2009 RH Designs (RHD)

This file contains the following information:
1.  License Agreement
2.  System requirements
3.  How to install / uninstall TV Viewer
4.  What is "TV Viewer"
5.  Future plans
6.  Disclaimer
7.  TV Viewer Registration


1.        License Agreement

USE OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE LICENSE TERMS SET FORTH
BELOW. USING THE SOFTWARE INDICATES YOUR ACCEPTANCE OF THESE TERMS. IF
YOU DO NOT ACCEPT THESE TERMS, YOU MUST DELETE THE SOFTWARE IMMEDIATELY.
"Use" means storing, loading, installing, executing or displaying the
software. You may not modify the software or disable any licensing or
control features of the software or revers engineer the software.

This software is shareware! If you want to use the program after a 30 day trial
period, you are required to buy your personal license of this software. 
You may not copy or reproduce the software for any purpose
except to make one (1) archival copy of the software, or te redistribute the shareware
version including this readme.txt file. You may not give
copies of this software to other people. You may not sell, rent or lease
the software to others. 

If you are a registered user, you are entitled to use this product for
your own use. You may not sell, rent or lease the software to others
without written permission of the author (RHD). You may use only
one copy of the software at one time. You may not use this software on a
network or on more than one computer at the same time without a license for
"concurrent use". 

You must not give away your personal copy. Doing so will result in an
infringement of copyright. RHD retains the right of claims for
compensation in respect of damage which occurred by your giving away of the
software copy. This claim shall also extent to all costs which RHD
incurs in defending himself.

THE SOFTWARE IS WARRANTED IF AT ALL ONLY ACCORDING TO THE TERMS OF THIS
LICENSING AGREEMENT. EXCEPT AS WARRANTED HEREIN, RHD HEREBY DISCLAIMS ALL
WARRANTIES AND CONDITIONS WITH REGARD TO THE SOFTWARE, INCLUDING ALL IMPLIED
WARRANTIES AND CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE, TITLE AND NON-INFRINGEMENT.


2.        System requirements

If you are using a capture card, you will need to use a VCR
as Tuner, and connect the Video-out connection of the VCR with the capture card.

You need a working Video for Windows compatible video capture device installed
in your system. TV Viewer runs on all W9x and NT 4 or better platforms.
The driver of your capture card must support overlay, and must be able to stretch.

Known supported cards:
Please visit the website at:
http://tvviewer.browseto.org for the latest information of (un)supported cards

If you have a card which is not in this list, please mail me whether it works at:
ronaldholthuizen@hotmail.com


3.        How to install / uninstall "TV Viewer"

You must have DirectX6 and DXMedia5.2 or higher installed. These files may
already be installed. You can start the trial version, and if it works
you have these files installed. If the program gives an error message about
a missing DLL file, you must download and install DirectX6 and DXMedia.
To download and install these files go to http://www.microsoft.com/directx

Further installation is very easy. Unzip the zip-file to
whatever directory you want and start it up from there. There are no other
files in the system changed.
There are NO registry settings or Windows directory settings created or
modified.  To uninstall the program, just delete "TV Viewer.EXE" (or
TV Viewer_TRIAL.EXE)


4.        What is "TV Viewer"

"TV Viewer" is a program that will allow you to view the input of your capture
card, at full screen size, with using only a very small amount of
system resources. This program will make a TV board of your capture card!


5.        Future plans

- Possibly support for Multiple Monitor Systems


6.	  Disclaimer

Don't forget that there are no warranties associated with this software.
While we believe that the software is reasonably bug free and well
behaved, We are in no way responsible if the software does not work the
way you would expect it to work. If it locks up your computer,
garbles your floppy disks or hard drive or does any other harmful thing
to your computer - it is entirely your problem. RHD is not liable
for any infringements or damages of third parties' rights resulting in your 
use of this product. RHD is in not liable for, and  does not 
warrant the trustworthiness, quality, industrial use, or serviceability of 
this product for the supposed purpose or any other purposes.

This information may be subject to change. All brand and product names
are trademarks and/or registered trademarks of their respective owners.
All rights reserved.
(c) 2000-2002 RH Designs (RHD) Dresdenlaan 4, Son, The Netherlands


7.	TV Viewer Registration


Registration fee US $: 10.00

If you would like to register TV Viewer, click on 'Help->Buy Online' in 
the menu bar of TV Viewer.
------------------------------------------------------------------------------


