"Gallery Creator"
This program is shareware.
For more info see the registration section in this document.
--------------------------------------------------------------------------

Copyright (c) 2004 RH Designs (RHD)

This file contains the following information:
1.  License Agreement
2.  System requirements
3.  How to install / uninstall Gallery Creator
4.  What is "Gallery Creator"
5.  Future plans
6.  Disclaimer
7.  Gallery Creatorr Registration


1.        License Agreement

USE OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE LICENSE TERMS SET FORTH
BELOW. USING THE SOFTWARE INDICATES YOUR ACCEPTANCE OF THESE TERMS. IF
YOU DO NOT ACCEPT THESE TERMS, YOU MUST DELETE THE SOFTWARE IMMEDIATELY.
"Use" means storing, loading, installing, executing or displaying the
software. You may not modify the software or disable any licensing or
control features of the software or revers engineer the software.

This software is shareware! If you want to use the program after a 30 day trial
period, you are required to buy your personal license of this software. 
You may not copy or reproduce the software for any purpose
except to make one (1) archival copy of the software, or te redistribute the shareware
version including this readme.txt file. You may not give
copies of this software to other people. You may not sell, rent or lease
the software to others. 

If you are a registered user, you are entitled to use this product for
your own use. You may not sell, rent or lease the software to others
without written permission of the author (RHD). You may use only
one copy of the software at one time. You may not use this software on a
network or on more than one computer at the same time without a license for
"concurrent use". 

You must not give away your personal copy. Doing so will result in an
infringement of copyright. RHD retains the right of claims for
compensation in respect of damage which occurred by your giving away of the
software copy. This claim shall also extent to all costs which RHD
incurs in defending himself.

THE SOFTWARE IS WARRANTED IF AT ALL ONLY ACCORDING TO THE TERMS OF THIS
LICENSING AGREEMENT. EXCEPT AS WARRANTED HEREIN, RHD HEREBY DISCLAIMS ALL
WARRANTIES AND CONDITIONS WITH REGARD TO THE SOFTWARE, INCLUDING ALL IMPLIED
WARRANTIES AND CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE, TITLE AND NON-INFRINGEMENT.


2.        System requirements

Windows 98, ME, 2000, XP or better
At least 32 Mb memory
At least a Pentium or compatible processor

.Net Framework available for free from Microsoft (http://windowsupdate.microsoft.com).

3.        How to install / uninstall "Gallery Creatorr"

Just run the program. If you get an error saying you are missing mscoree.dll, you need to install the .Net Framework available for free from Microsoft (http://windowsupdate.microsoft.com).



4.        What is "Gallery Creator"

Create your own Image Gallery for the internet has never been so easy!
With the Thumbnail & Wabpage creator, you can create you own gallery in a matter of seconds!

No complex user-interface are tons of options you are not going to use. No HTML knowledge no required. Just a simple program that can be used by everyone.
Ideal for putting your photos on the internet. (Supported image formats: Jpeg, Png, Gif, Bmp and Tiff)


To create your own gallery in a matter of seconds:

1. Put all you images on your computer in a single folder
2. Start the Thumbnail & Webpage Creator program. (If you are getting an error about a missing DLL, you need to install the .Net Framework available for free from Microsoft).
3. Press the button 'Select Files & Go'
4. Select all the files you want to see in your gallery.
5. Press OK.
6. You Gallery will be created, and automatically opened in your default internet browser.


5.        Future plans

- Better looking Galleries with multiple style options


6.	  Disclaimer

Don't forget that there are no warranties associated with this software.
While we believe that the software is reasonably bug free and well
behaved, We are in no way responsible if the software does not work the
way you would expect it to work. If it locks up your computer,
garbles your floppy disks or hard drive or does any other harmful thing
to your computer - it is entirely your problem. RHD is not liable
for any infringements or damages of third parties' rights resulting in your 
use of this product. RHD is in not liable for, and  does not 
warrant the trustworthiness, quality, industrial use, or serviceability of 
this product for the supposed purpose or any other purposes.

This information may be subject to change. All brand and product names
are trademarks and/or registered trademarks of their respective owners.
All rights reserved.
(c) 2004 RH Designs (RHD) Dresdenlaan 4, Son, The Netherlands


7.	Gallery Creator Registration


Registration fee US $: 5.00

If you would like to register Gallery Creator, Open the buy.html file.
------------------------------------------------------------------------------


